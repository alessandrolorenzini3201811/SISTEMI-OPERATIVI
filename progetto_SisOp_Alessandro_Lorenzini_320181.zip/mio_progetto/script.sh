if test $# -lt 2
then
	echo "Usage: $0 FILE_NAME   NUMERI DA VIRIFICARE "
	exit -1
fi
make -f makefile
./calcolatore $2 &
./memorizzatore $1  

