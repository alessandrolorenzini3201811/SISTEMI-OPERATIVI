#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include "mysocket.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <limits.h>

#define TRUE	1
#define FALSE 	0

FILE *fd;



int s;
// QUESTO ALGORITMO SERVE PER ORDINARE IN NUMERI ALL'INTERNO DELL'ARRAY PERCHE' NON POSSIAMO SAPERE QUALE PARTE DI NUMERI PRIMI VERRA' INVIATA,TANTO E' VERO CHE TESTANDO IL PROGRAMMA MOLTO SPESSO VENIVANO INVIATI PRIMA INUMERI DA 2/3 A n POI DA 1 A1/3 E IN FNE DA 1/3 A 2/3
void SelectionSort(int a[], int dim){
	int i, j, min, tmp;
	for(i=0;i<dim-1;i++){
		min=i;
		for(j=i+1;j<dim; j++){
			if(a[j]<a[min])
                     min=j;
		}
	tmp=a[min];
        a[min]=a[i];
        a[i]=tmp;
	}
}







int main(int argc, char *argv[])
{

int sock,accetta;
int numero;


printf("\ncreazione socket in /tmp/sock");
struct sockaddr_un saddr={AF_UNIX,"/tmp/sock"};
sock= socket(AF_UNIX,SOCK_STREAM,0);
printf("\nUnlink /tmp/sock");
unlink("/tmp/sock");

if(bind(sock,(struct sockaddr*)&saddr,sizeof(saddr))<0){
	perror("\nERRORE BIND");
	}

printf("\nlisten");
listen(sock,1);

socklen_t size=sizeof(saddr);
printf("\naccept");
accetta=accept(sock,(struct sockaddr *)&saddr, &size);

int i=0;	
	

//CON QUESTO FOPEN VADO A APRIRE UN FILE
printf("\ncreazione array\n");
if((fd=fopen(argv[1],"w"))==NULL)printf("Open error\n");
printf("\nOPEN AVVIATA\n");
read(accetta, &s, sizeof(int));
int sBuffer[s];
do{
	if(accetta == -1){
			if(errno != EINTR)
				handle_error("accept");
			else {
				printf("Accept interrotta da Signal!!!\n");
				continue;
			}
		}
		read(accetta, &numero, sizeof(int));
		if(numero!=INT_MAX)
		sBuffer[i] = numero;
		i++;
		

}while(numero!=INT_MAX);

SelectionSort(sBuffer, s);
//CON QUESTO FOR VADO A SCRIVERE SUL FILE I NUMERI PRESENTI NELL'ARREY
for(int u=0;u<i-1;u++){
	fprintf(fd,"num primo %d \n",sBuffer[u]);
	
	
}

fclose(fd);

return 0;
}
