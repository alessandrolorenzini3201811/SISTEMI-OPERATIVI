#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include "mysocket.h"
#include <stdbool.h>
#include <pthread.h>
#include <limits.h>


#define TRUE	1
#define FALSE 	0
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int vettore[150000000];
int s=0;
int N=0;



void calcola_primo1(int var) {
int div=2;
int primo=1;
int i;
double var1;

if(var==1){var1=0.333333*N;
i=2;
}
else if(var==2){var1=0.666666*N;
i=0.333333*N;
}
else{var1=N;
i=0.666666*N;
}
while(i<var1){
div=2;
primo=1;
	while(div<i){
	
		if((i%div)==0){
			primo=0;
			break;
		}else{
			div=div+1;
			}
			
	}
	
	if(primo==1){
		vettore[s]=i;
		s++;
	}
//HO DECISO DI USARE MUTEX QUI IN MODO TALE DA NON CREALE CONFLITTI NELL'INCREMENTO DELLA VARIABILE I IN QUANTO ESSA MI STABILISCE IL PROSEGUIMENTO DEL CONTROLLO
pthread_mutex_lock(&mutex);
if(i<var1)
 i++;
pthread_mutex_unlock(&mutex);
}

pthread_exit(NULL);
}



int main(int argc, char *argv[])
{
	
	int sock;
	int k;
	
	
	k=atol(argv[1]);
	printf("%d\n",k);
	N=k;
	struct sockaddr_un saddr={AF_UNIX,"/tmp/sock"};
	sock= socket(AF_UNIX,SOCK_STREAM,0);
	int numero_invio=0;
	
	

	if(sock == -1)
		handle_error("socket");

	socklen_t size=sizeof(saddr);
	
	if(connect(sock,(struct sockaddr *)&saddr,size ) == -1)
		handle_error("connect");
		
		
	bool i=TRUE;
	int j=0;
	pthread_t th1,th2,th3; 
	pthread_t *calc_thread[3]={&th1,&th2,&th3};
	
	//CON QUESTO FOR VADO A CREARE I TRE THREAD CHE CALCOLERANNO I I NUMERI PRIMI DA 1 A 1/3N ,1/3 A 2/3 E INFINE DA 2/3 A N
	int error,errori;
	for(int a=1;a<=3;a++)
		if((error=pthread_create(calc_thread[a-1], NULL,(void *)calcola_primo1,(void *)(intptr_t)a))!=0){
			perror("errore nel thread");
			exit(1);	
			}
		
	
	for(int j=0;j<3;j++)
	if((errori=pthread_join(*calc_thread[j],NULL))!=0){
			perror("errore nel thread");
			exit(1);	
			}
	
	write(sock,&s, sizeof(int));
	//INVIO DEI DATI
	while(i){
	
	numero_invio=vettore[j];
		j++;
		if(j>s){
			i=FALSE;
			numero_invio=INT_MAX;
			write(sock,&numero_invio, sizeof(int));
			}else if(numero_invio!=0){
			write(sock, &numero_invio, sizeof(int));
			}
	}
	
	close(sock);

	return 0;
}

