#include <errno.h>

#define MY_SOCK_PATH "/tmp/sock"
#define LISTEN_BACKLOG 50   /* The  backlog  argument defines the maximum length to which the queue of pending connections 
							   for sockfd may grow.  If a connection request arrives  when  the  queue  is
							   full,  the client may receive an error with an indication of ECONNREFUSED or, if the
							   underlying protocol supports retransmission, the request may be ignored  so  that  a
							   later reattempt at connection succeeds. */
#define MAX_BUFFER_LEN	256
#define PORT			5152
#define NET_ADDRESS		"10.0.2.15"

#define handle_error(msg) \
   do { printf("errno = %d\n", errno); perror(msg); exit(EXIT_FAILURE); } while (0)
	   
//#define ___AF_INET___
